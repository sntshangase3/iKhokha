package com.ikhokha.techcheck;

import java.util.concurrent.BlockingQueue;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Consumer implements Runnable{
    private BlockingQueue<String> queue;
	Map<String, Integer> resultsMap = new HashMap<>();

    public Consumer(BlockingQueue<String> q){
        queue = q;
    }

    public void run(){
        while(true){
            String line = queue.poll();

            if(line == null && !Main.isProducerAlive())
                return;

            if(line != null){
               // System.out.println(Thread.currentThread().getName()+" processing line: "+line);
                //Do something with the line here like see if it contains a string
                Map<String, Integer> totalResults = new HashMap<>();
    		

    				// 1. DEBUGGING AND LOGICAL PROBLEM SOLVING

    				/*
    				 * if (line.length() < 15) {
    				 * 
    				 * incOccurrence(resultsMap, "SHORTER_THAN_15");
    				 * 
    				 * } if (line.toLowerCase().contains("mover")) {
    				 * 
    				 * incOccurrence(resultsMap, "MOVER_MENTIONS");
    				 * 
    				 * } if (line.toLowerCase().contains("shaker")) {
    				 * 
    				 * incOccurrence(resultsMap, "SHAKER_MENTIONS");
    				 * 
    				 * }
    				 */

    				// 2. OBJECT ORIENTED DESIGN
    				addShort(line, 15);
    				addMetric(line, "mover", "MOVER_MENTIONS");
    				addMetric(line, "shaker", "SHAKER_MENTIONS");
    				addMetric(line, "?", "QUESTIONS ");
    				addMetric(line, "http", "SPAM ");
                
    		
    			addReportResults(resultsMap, totalResults);
    			
    			// 1. DEBUGGING AND LOGICAL PROBLEM SOLVING
    			//System.out.println(commentFile.getName());
    			System.out.println("--------------------");
    			totalResults.forEach((k,v) -> System.out.println(k + " : " + v));			
    			System.out.println();
    			//totalResults.clear();
            }

        }
    }

    private void incOccurrence(Map<String, Integer> countMap, String key) {

		countMap.putIfAbsent(key, 0);
		countMap.put(key, countMap.get(key) + 1);
	}
    private static void addReportResults(Map<String, Integer> source, Map<String, Integer> target) {

		for (Map.Entry<String, Integer> entry : source.entrySet()) {
			target.put(entry.getKey(), entry.getValue());
			//System.out.println(entry.getKey()+" : "+entry.getValue());
			
		}
		
	}
	public int CountOccurrences(String str, String strFind) {

		int count = 0, fromIndex = 0;

		while ((fromIndex = str.indexOf(strFind, fromIndex)) != -1) {

			count++;
			fromIndex++;

		}

		return count;
	}

	public void addShort(String comment, int shorter) {

		boolean isShort = comment.length() < shorter;
		if (isShort) {

			incOccurrence(resultsMap, "SHORTER_THAN_" + shorter);

		}

	}

	public void addMetric(String comment, String key, String matric) {

		boolean isFound = comment.toLowerCase().indexOf(key.toLowerCase()) != -1;

		if (isFound) {
			// Check multiple occurrences in one comment
			int occur = CountOccurrences(comment.toLowerCase(), key.toLowerCase());
			for (int i = 1; i <= occur; i++) {
				incOccurrence(resultsMap, matric.toUpperCase());
			}

		}

	}

}
