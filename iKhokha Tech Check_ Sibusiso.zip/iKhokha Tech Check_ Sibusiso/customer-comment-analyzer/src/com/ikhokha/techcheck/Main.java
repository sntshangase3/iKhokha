package com.ikhokha.techcheck;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class Main  {
	   private static final int NUMBER_OF_CONSUMERS = 3;
	    private static final int NUMBER_OF_PRODUCERS = 3;
	    private static final int QUEUE_SIZE = 2;
	    private static BlockingQueue<String> queue;
	    private static Collection<Thread> producerThreadCollection, allThreadCollection;

	public static void main(String[] args) {
		
	
		File docPath = new File("docs");
		File[] commentFiles = docPath.listFiles((d, n) -> n.endsWith(".txt"));
		System.out.println("RESULTS PER FILE/DAY\n===================");
		
		for (File commentFile : commentFiles) {
			Map<String, Integer> totalResults = new HashMap<>();
			CommentAnalyzer commentAnalyzer = new CommentAnalyzer(commentFile);
			Map<String, Integer> fileResults = commentAnalyzer.analyze();
			addReportResults(fileResults, totalResults);
			
			// 1. DEBUGGING AND LOGICAL PROBLEM SOLVING
			System.out.println(commentFile.getName());
			System.out.println("--------------------");
			totalResults.forEach((k,v) -> System.out.println(k + " : " + v));			
			System.out.println();
			//totalResults.clear();
		}
		
		// 3. CONCURRENCY
		/*
		  producerThreadCollection = new ArrayList<Thread>();
	        allThreadCollection = new ArrayList<Thread>();
	        queue = new LinkedBlockingDeque<String>(QUEUE_SIZE);

	        createAndStartProducers();
	        createAndStartConsumers();

	        for(Thread t: allThreadCollection){
	            try {
	                t.join();
	            } catch (InterruptedException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	        }
*/
		
		
	}
	
	/**
	 * This method adds the result counts from a source map to the target map 
	 * @param source the source map
	 * @param target the target map
	 */
	private static void addReportResults(Map<String, Integer> source, Map<String, Integer> target) {

		for (Map.Entry<String, Integer> entry : source.entrySet()) {
			target.put(entry.getKey(), entry.getValue());
			//System.out.println(entry.getKey()+" : "+entry.getValue());
			
		}
		
	}
	
	  private static void createAndStartProducers(){
		  File docPath = new File("docs");
			File[] commentFiles = docPath.listFiles((d, n) -> n.endsWith(".txt"));
			int i=1;
			for (File commentFile : commentFiles) {
				  Producer producer = new Producer(Paths.get(commentFile.getAbsolutePath()), queue);
	            Thread producerThread = new Thread(producer,"producer-"+i);
	            producerThreadCollection.add(producerThread);
	            producerThread.start();
	            i++;
			}
	       
	        allThreadCollection.addAll(producerThreadCollection);
	    }

	    private static void createAndStartConsumers(){
	        for(int i = 0; i < NUMBER_OF_CONSUMERS; i++){
	            Thread consumerThread = new Thread(new Consumer(queue), "consumer-"+i);
	            allThreadCollection.add(consumerThread);
	            consumerThread.start();
	        }
	    }

	    public static boolean isProducerAlive(){
	        for(Thread t: producerThreadCollection){
	            if(t.isAlive())
	                return true;
	        }
	        return false;
	    }


}
